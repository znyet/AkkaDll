﻿using Akka.Actor;
using Akka.Serialization;
using MessagePack;
using System;

namespace Akka.MySerializer
{
    public class MsgPackLz4: Serializer
    {
        public MsgPackLz4(ExtendedActorSystem system) : base(system)
        {

        }

        public override int Identifier { get; } = 1234566;

        public override bool IncludeManifest => true;

        public override byte[] ToBinary(object obj)
        {
            return LZ4MessagePackSerializer.Serialize(obj);
        }

        public override object FromBinary(byte[] bytes, Type type)
        {
            return LZ4MessagePackSerializer.NonGeneric.Deserialize(type, bytes);
        }
    }
}
