﻿using Akka.Actor;
using Akka.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Akka.IO;
using System.Threading;
using Akka.Event;
using Akka.Pattern;

namespace TestAkka.Remote.Server
{
    class Program
    {
        static void Main(string[] args)
        {
            var config = ConfigurationFactory.ParseString(@"
akka { 
    actor.debug.unhandled = on
    loggers = [""Akka.Logger.NLog.NLogLogger, Akka.Logger.NLog""]
    stdout-loglevel = DEBUG
    loglevel = DEBUG
    log-config-on-start = on   
    actor {
        provider = ""Akka.Remote.RemoteActorRefProvider,Akka.Remote""
    }
    remote {
        dot-netty.tcp {
            port = 8123
            hostname = 0.0.0.0
            public-hostname = 192.168.1.233
            message-frame-size =  30000000b
            send-buffer-size =  30000000b
            receive-buffer-size =  30000000b
            maximum-frame-size = 30000000b
            connection-timeout = 2 s
        }
        watch-failure-detector {
            heartbeat-interval = 2 s
            acceptable-heartbeat-pause = 0 s
        }
    }

}
");


            ActorSystem system = ActorSystem.Create("MyServer", config);
            IActorRef chatServer = system.ActorOf(Props.Create(() => new ChatServerActor()), "ChatServer");

            

            Console.ReadLine();
        }
    }



    class ChatServerActor : ReceiveActor, ILogReceive
    {
        static List<IActorRef> dict = new List<IActorRef>();

        private readonly ILoggingAdapter _log = Logging.GetLogger(Context); 

        public ChatServerActor()
        {

            Receive<ConnectRequest>(message =>
            {
                
                dict.Add(Sender);
                Context.Watch(Sender);
                Console.WriteLine(dict.Count);

                Console.WriteLine("one clinet in " + message.Name);
                var msg = new MyMessage() { Name = "你好欢迎来到服务器 " + message.Name };

                Sender.Tell(msg);

                Sender.Tell(new ConnectRequest() { Name = "ok" });

                Console.WriteLine("有人连接了服务器");

                //Console.WriteLine(Sender.Path);
                //Console.WriteLine(Context.GetChildren().Count());

                throw new Exception("aaaaaaaaaaaa");

            });


            Receive<ByteMessage>(msg =>
            {
                byte[] data = msg.Data;
                Console.WriteLine(Encoding.UTF8.GetString(data));
                Console.WriteLine(Sender.Path);
            });


            Receive<MyMessage>(msg =>
            {
                Console.WriteLine(msg.Name);
                Console.WriteLine(Sender.Path);
                //Console.WriteLine(Sender.Path);
                //Console.WriteLine(Sender.Equals(Self));
            });

            Receive<string>(msg =>
            {
                Console.WriteLine("收到字符串消息：" + msg);
                Sender.Tell("ok啦");
            });

            Receive<byte[]>(msg =>
            {
                Console.WriteLine("我收到了byte[] ：" + msg.Length);
                Console.WriteLine(msg[3]);

                var act = Context.ActorSelection(Sender.Path);
                act.Tell("11111111111111");

                var act2 = Context.ActorSelection(Sender.Path.ToString());
                act2.Tell("22222222222222");

            });


            Receive<Terminated>(msg =>
            {
                Console.WriteLine("有东西掉线了");
                Context.Unwatch(msg.ActorRef);
                Context.Stop(msg.ActorRef);
                dict.Remove(msg.ActorRef);
                Console.WriteLine(dict.Count);
            });

            Receive<ReceiveTimeout>(msg =>
            {
                Console.WriteLine("超时");
            });

        }


        protected override SupervisorStrategy SupervisorStrategy()
        {
            return new OneForOneStrategy(
                maxNrOfRetries: 10,
                withinTimeRange: TimeSpan.FromMinutes(1),
                localOnlyDecider: ex =>
                {
                    Console.WriteLine("exexexexeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                    switch (ex)
                    {
                        case ArithmeticException ae:
                            return Directive.Resume;
                        case NullReferenceException nre:
                            return Directive.Restart;
                        case ArgumentException are:
                            return Directive.Stop;
                        default:
                            return Directive.Escalate;
                    }
                });
        }


    }
}