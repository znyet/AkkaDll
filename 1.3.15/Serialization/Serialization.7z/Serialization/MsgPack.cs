﻿using Akka.Actor;
using Akka.Serialization;
using System;
using MessagePack;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Akka.MySerializer
{
    public class MsgPack : Serializer
    {
        public MsgPack(ExtendedActorSystem system) : base(system)
        {

        }

        public override int Identifier { get; } = 1234567;

        public override bool IncludeManifest => true;

        public override object FromBinary(byte[] bytes, Type type)
        {
            Console.WriteLine("========================>MsgPack FromBinary");
            return MessagePackSerializer.NonGeneric.Deserialize(type, bytes);
        }

        public override byte[] ToBinary(object obj)
        {
            Console.WriteLine("========================>MsgPack ToBinary");
            return MessagePackSerializer.Serialize(obj);
        }
    }
}
