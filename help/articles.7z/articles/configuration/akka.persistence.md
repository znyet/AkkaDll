## Akka.Persistence Configuration
Below is the default HOCON configuration for the base `Akka.Persistence` package.

[!code[Akka.Persistence.dll HOCON Configuration](../../../src/core/Akka.Persistence/persistence.conf)]