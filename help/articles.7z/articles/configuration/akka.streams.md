## Akka.Streams Configuration
Below is the default HOCON configuration for the base `Akka.Steams` package.

[!code[Akka.Streams.dll HOCON Configuration](../../../src/core/Akka.Streams/reference.conf)]