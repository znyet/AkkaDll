## Akka.Remote Configuration
Below is the default HOCON configuration for the base `Akka.Remote` package.

[!code[Akka.Remote.dll HOCON Configuration](../../../src/core/Akka.Remote/Configuration/Remote.conf)]