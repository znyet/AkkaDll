## Akka Configuration
Below is the default HOCON configuration for the base `Akka` package.

[!code[Akka.dll HOCON Configuration](../../../src/core/Akka/Configuration/Pigeon.conf)]