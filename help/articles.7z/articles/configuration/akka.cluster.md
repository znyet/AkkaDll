## Akka.Cluster Configuration
Below is the default HOCON configuration for the base `Akka.Cluster` package.

[!code[Akka.Cluster.dll HOCON Configuration](../../../src/core/Akka.Cluster/Configuration/Cluster.conf)]