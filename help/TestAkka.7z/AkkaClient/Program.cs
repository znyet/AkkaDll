﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Akka.Configuration;
using Akka.Actor;
using Akka.Event;
using Akka.Remote;
using Akka.Routing;

namespace AkkaClient
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //serilog
            //var file = AppDomain.CurrentDomain.BaseDirectory + @"log\log.txt";
            //var logger = new LoggerConfiguration()
            //    .WriteTo.Console()
            //    .WriteTo.File(file, rollingInterval: RollingInterval.Day)
            //    //.MinimumLevel.Information()
            //    .CreateLogger();
            //Log.Logger = logger;

            var configIni = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "Config.ini");
            var config = ConfigurationFactory.ParseString(configIni);

            var system = ActorSystem.Create("clientSys", config); //root

            //订阅连接和断开事件
            var eventActor = system.ActorOf(Props.Create<EventActor>());
            system.EventStream.Subscribe<DeadLetter>(eventActor);
            system.EventStream.Subscribe<AssociatedEvent>(eventActor);
            system.EventStream.Subscribe<AssociationErrorEvent>(eventActor);
            system.EventStream.Subscribe<DisassociatedEvent>(eventActor);
            system.EventStream.Subscribe<RemotingListenEvent>(eventActor);
            system.EventStream.Subscribe<RemotingShutdownEvent>(eventActor);
            system.EventStream.Subscribe<RemotingErrorEvent>(eventActor);

            //创建无连接池的actor
            //var actor = system.ActorOf(Props.Create(() => new MyActor()), "client");
            //var actor = system.ActorOf<MyActor>("client");

            //创建有连接池的actor
            var props = Props.Create<MyActor>().WithRouter(new RoundRobinPool(5));
            var actor = system.ActorOf(props, "client");

            string serverUrl = "akka.tcp://serverSys@localhost:2552/user/server";
            var server = system.ActorSelection(serverUrl); //添加新的服务地址 

            //tell
            server.Tell(1, actor);

            //ask
            var data = server.Ask<int>(3, TimeSpan.FromSeconds(3)).Result;
            Console.WriteLine("Ask Result:" + data);

            Console.ReadKey();

        }
    }

    class EventActor : ReceiveActor
    {
        public EventActor()
        {
            Receive<DeadLetter>(msg =>
            {
                Console.WriteLine("=====> DeadLetter");
            });

            Receive<AssociatedEvent>(msg =>  //一般用到这个
            {
                Console.WriteLine("=====> AssociatedEvent 链接成功建立事件");
                Console.WriteLine(msg.RemoteAddress.ToString());
            });

            Receive<AssociationErrorEvent>(msg =>
            {
                Console.WriteLine("=====> AssociationErrorEvent 链接相关错误事件");
            });

            Receive<DisassociatedEvent>(msg => //一般用到这个
            {
                Console.WriteLine("=====> DisassociatedEvent 链接结束事件");
                Console.WriteLine(msg.RemoteAddress);
            });

            Receive<RemotingListenEvent>(msg =>
            {
                Console.WriteLine("=====> RemotingListenEvent 远程子系统准备好接受链接时的事件");
            });

            Receive<RemotingShutdownEvent>(msg =>
            {
                Console.WriteLine("=====> RemotingShutdownEvent 远程子系统被关闭的事件");
            });

            Receive<RemotingErrorEvent>(msg =>
            {
                Console.WriteLine("=====> RemotingErrorEvent 远程相关的所有错误");
            });

        }
    }

    class MyActor : ReceiveActor, ILogReceive
    {
        public MyActor()
        {
            //收到请求消息的时候
            Receive<int>(msg =>
            {
                Console.WriteLine(msg);
                Console.WriteLine(Sender.Path);
            });


        }
    }
}




