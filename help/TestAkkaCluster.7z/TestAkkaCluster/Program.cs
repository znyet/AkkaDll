﻿using Akka.Actor;
using Akka.Cluster.Tools.Client;
using Akka.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAkkaCluster
{
    class Program
    {
        static void Main(string[] args)
        {


            string configIni = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "Config.ini");

            var config = ConfigurationFactory.ParseString(configIni);
            var system = ActorSystem.Create("ClusterSystem", config);

            //var listener = system.ActorOf(Props.Create(typeof(SimpleClusterListener)), "clusterListener");
            //var publisher = system.ActorOf(Props.Create<Publisher>(), "publisher");
            //publisher.Tell("hello");
            //var subscriber = system.ActorOf(Props.Create<Subscriber>(), "subscriber");
            //var destination = system.ActorOf(Props.Create<Destination>(), "destination");
            //var sender = system.ActorOf(Props.Create<Sender>(), "sender");

            var serviceA = system.ActorOf(Props.Create<Service>(),"serviceA");
            ClusterClientReceptionist.Get(system).RegisterService(serviceA);


            Console.ReadKey();
        }
    }
}
