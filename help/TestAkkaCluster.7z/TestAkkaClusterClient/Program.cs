﻿using Akka.Actor;
using Akka.Cluster.Tools.Client;
using Akka.Configuration;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TestAkkaClusterClient
{
    class Program
    {
        static void Main(string[] args)
        {
            string configIni = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "Config.ini");
            var config = ConfigurationFactory.ParseString(configIni);

            var system = ActorSystem.Create("ClusterClient", config);

            var initialContacts = new List<ActorPath>()
            {
                ActorPath.Parse("akka.tcp://ClusterSystem@localhost:2551/system/receptionist"),
                ActorPath.Parse("akka.tcp://ClusterSystem@localhost:2552/system/receptionist"),
                //ActorPath.Parse("akka.tcp://ClusterSystem@localhost:2553/system/receptionist")

            }.ToImmutableHashSet();

            var settings = ClusterClientSettings.Create(system).WithInitialContacts(initialContacts);

            var c = system.ActorOf(ClusterClient.Props(settings), "client");


            Task.Run(() =>
            {
                while (true)
                {
                    c.Tell(new ClusterClient.Send("/user/serviceA", "hello", localAffinity: true));
                    //c.Tell(new ClusterClient.SendToAll("/user/serviceA", "hello"));
                    //c.Tell(new ClusterClient.Publish("content", "你好"));
                    Thread.Sleep(1000);
                }

            });




            Console.ReadKey();
        }
    }
}
