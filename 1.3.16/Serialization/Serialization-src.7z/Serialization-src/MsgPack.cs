﻿using Akka.Actor;
using Akka.Serialization;
using MessagePack;
using System;

namespace Akka.MySerializer
{
    public class MsgPack : Serializer
    {
        public MsgPack(ExtendedActorSystem system) : base(system)
        {

        }

        public override int Identifier { get; } = 1234567;

        public override bool IncludeManifest => true;

        public override byte[] ToBinary(object obj)
        {
            return MessagePackSerializer.Serialize(obj);
        }

        public override object FromBinary(byte[] bytes, Type type)
        {
            return MessagePackSerializer.NonGeneric.Deserialize(type, bytes);
        }
    }
}
