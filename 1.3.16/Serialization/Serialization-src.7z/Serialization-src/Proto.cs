﻿using Akka.Actor;
using Akka.Serialization;
using System;
using System.IO;

namespace Akka.MySerializer
{
    public class Proto : Serializer
    {

        public Proto(ExtendedActorSystem system) : base(system)
        {

        }

        public override int Identifier { get; } = 1234568;

        public override bool IncludeManifest => true;


        public override byte[] ToBinary(object obj)
        {
            return ProtoHelper.Serialize(obj);
        }


        public override object FromBinary(byte[] bytes, Type type)
        {
            return ProtoHelper.Deserialize(bytes, type);
        }
    }

    class ProtoHelper
    {
        public static byte[] Serialize(object val)
        {
            using (var ms = new MemoryStream())
            {
                ProtoBuf.Serializer.Serialize(ms, val);
                return ms.ToArray();
            }
        }


        public static object Deserialize(byte[] bytes, Type t)
        {
            using (var ms = new MemoryStream(bytes))
            {
                return ProtoBuf.Serializer.Deserialize(t, ms);
            }
        }
    }

}
